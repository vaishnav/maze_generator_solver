import dataManage
import random
import pdb                                   #for debugging



maze_size = (4,4)
# using dict comprehension to genrate graph for maze
maze = {(x,y):[] for x in range(maze_size[0]) for y in range(maze_size[1])}




def neighbor_find(element):       #find the neighbors of particular node
    neighbors = []
    x = element[0]
    y = element[1]

    if(x-1 >= 0):
        neighbors.append((x-1,y))

    if(x+1 < maze_size[0]):
        neighbors.append((x+1,y))

    if(y-1 >= 0):
        neighbors.append((x,y-1))

    if(y+1 < maze_size[1]):
        neighbors.append((x,y+1))

    return neighbors



def createMaze():
    # create maze with the help of recursive backtracking
    mazeFrontier = dataManage.stack()      #stack for genrating maze


    neighbors = []                             #store neighbors of each explored node
    node = (0,0)                               #initial state
    explored = [node]                          #empty explored states except of first state

    # pdb.set_trace()

    mazeFrontier.insert(node)             #starting from first block of the maze from top left

    while(not mazeFrontier.isEmpty()):
        neighbors = neighbor_find(node)

        neighbors = list(set(neighbors)-set(explored))      #to remove already visited neighbors
                                                            #   from the "neighbors" list


        if(len(neighbors)==0):
            node = mazeFrontier.remove()
            continue


        next_node = neighbors[random.randint(0,len(neighbors)-1)]
        maze[node].append(next_node)
        mazeFrontier.insert(next_node)
        node = next_node
        explored.append(node)




def main():
    createMaze()
    print(maze)

if __name__ == "__main__":
    main()
